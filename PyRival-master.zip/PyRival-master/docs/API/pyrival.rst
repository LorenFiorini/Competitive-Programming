API Reference
=============

.. toctree::
   :maxdepth: 4

   pyrival.algebra
   pyrival.combinatorics
   pyrival.data_structures
   pyrival.geometry
   pyrival.graphs
   pyrival.linear_algebra
   pyrival.misc
   pyrival.numerical
   pyrival.strings
   pyrival.tools
