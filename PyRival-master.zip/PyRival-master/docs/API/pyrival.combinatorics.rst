pyrival.combinatorics
=====================

pyrival.combinatorics.combinatorics
-----------------------------------

.. automodule:: pyrival.combinatorics.combinatorics
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.combinatorics.nCr\_mod
------------------------------

.. automodule:: pyrival.combinatorics.nCr_mod
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.combinatorics.partitions
--------------------------------

.. automodule:: pyrival.combinatorics.partitions
   :members:
   :undoc-members:
   :show-inheritance:
