pyrival.geometry
================

pyrival.geometry.convex\_hull
-----------------------------

.. automodule:: pyrival.geometry.convex_hull
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.geometry.lines
----------------------

.. automodule:: pyrival.geometry.lines
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.geometry.polygons
-------------------------

.. automodule:: pyrival.geometry.polygons
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.geometry.vectors
------------------------

.. automodule:: pyrival.geometry.vectors
   :members:
   :undoc-members:
   :show-inheritance:
