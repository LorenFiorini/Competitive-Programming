pyrival.numerical
=================

pyrival.numerical.berlekamp\_massey
-----------------------------------

.. automodule:: pyrival.numerical.berlekamp_massey
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.numerical.hill\_climbing
--------------------------------

.. automodule:: pyrival.numerical.hill_climbing
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.numerical.integrate
---------------------------

.. automodule:: pyrival.numerical.integrate
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.numerical.interpolate
-----------------------------

.. automodule:: pyrival.numerical.interpolate
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.numerical.iroot
-----------------------

.. automodule:: pyrival.numerical.iroot
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.numerical.polynomial
----------------------------

.. automodule:: pyrival.numerical.polynomial
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.numerical.search
------------------------

.. automodule:: pyrival.numerical.search
   :members:
   :undoc-members:
   :show-inheritance:
