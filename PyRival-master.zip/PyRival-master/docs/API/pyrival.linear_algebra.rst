pyrival.linear\_algebra
=======================

pyrival.linear\_algebra.matrix
------------------------------

.. automodule:: pyrival.linear_algebra.matrix
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.linear\_algebra.max\_xor
--------------------------------

.. automodule:: pyrival.linear_algebra.max_xor
   :members:
   :undoc-members:
   :show-inheritance:

pyrival.linear\_algebra.multivariable\_crt
------------------------------------------

.. automodule:: pyrival.linear_algebra.multivariable_crt
   :members:
   :undoc-members:
   :show-inheritance:
