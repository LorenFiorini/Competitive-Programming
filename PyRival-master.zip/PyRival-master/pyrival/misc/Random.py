import sys

sys.modules["hashlib"] = sys.sha512 = sys
import random
