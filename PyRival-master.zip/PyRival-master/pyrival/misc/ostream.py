import sys


class ostream:
    def __lshift__(self, a):
        if a == endl:
            sys.stdout.write("\n")
            sys.stdout.flush()
        else:
            sys.stdout.write(str(a))
        return self


cout, endl = ostream(), object()
